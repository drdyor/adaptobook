import PdfUploader from './PdfUploader';
import './App.css';

function App() {
  return (
    <div className="App">
      <PdfUploader />
    </div>
  );
}

export default App;
